echo "Enter a file to copy it to the given directory"
read file
read dir

cp $file $dir
echo "File copied successfully..."
set -o noclobber

