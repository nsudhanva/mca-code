echo "Enter a File name"
read file
if [ -f $file ]
then
 echo "Select any one:"
 echo "1)Change permission using Octal values"
 echo "2)Change permission using Symbolic values"
 echo "3)Exit the script"
 echo "Enter your choice"
 read choice
 case $choice in 
   1) echo "You have selected to change permission using Octal value"
      echo "Please enter your value for User (ranging from 0-7)"
      read  u
      echo "Please enter your value for Group (ranging from 0-7)"
      read  g
      echo "Please enter your value for Others (ranging from 0-7)"
      read  o
      echo "Before changing permission:"
      echo `ls -l $file`
      if test [`sudo chmod $u$g$o $file`]
      then 
      echo "The file permission has been changed successfully"
      echo "Your new file permission is:"
      echo `ls -l $file`
      else
      echo "Error"
      fi
      ;; 
   
        2) echo "You have selected to change permission using Symbolic Representation"
   		
   		echo "1) Add permission"
   		echo "2) Remove permission"
   		read choice
   		case $choice in
   		
   			1) echo "Please enter to change permission for user or group or owner"
      read  x
      
      echo "For read write or execute permission"
      read  y
      
      echo "Before changing permission:"
      echo `ls -l $file`
      if test [`sudo chmod $x+$y $file`]
      then 
      echo "The file permission has been changed successfully"
      echo "Your new file permission is:"
      echo `ls -l $file`
      else
      echo "Error"
      fi
      ;;
   			
   			2)
   		echo "Please enter to change permission for user or group or owner"
      read  x
      
      echo "For read write or execute permission"
      read  y
      
      echo "Before changing permission:"
      echo `ls -l $file`
      if test [`sudo chmod $x-$y $file`]
      then 
      echo "The file permission has been changed successfully"
      echo "Your new file permission is:"
      echo `ls -l $file`
      else
      echo "Error"
      fi
      ;;
   *) echo "Wrong choice"  
 esac
 esac 
 else 
 echo "File does not exist"
 fi
