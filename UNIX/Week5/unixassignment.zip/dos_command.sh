  echo "Enter any given dos command to simulate the respective shell command"
	echo "DIR)Long lists files in the directory"
	echo "COPY)Copies files in the directory"
	echo "MOVE)Renames files in the directory"
	echo "cdd)Enter into test directory"
	echo "Enter the choice : "
	read choice

	case $choice in
	
	DIR) ls -l
				;;
				
	COPY) echo "Enter 2 Files to copy"
		    read file file2
				cp $file $file2
				;;
						 
	MOVE) echo "Enter 2 Files to move contents"
			  read file file2
			  mv $file $file2
			  ;;
			  
	cdd) alias cdd='cd test'
				;;
	*) echo "Wrong choice"
	esac
