<!DOCTYPE html>
<html>
<body>

<?php

echo "May 27, 2017 was on a ".date("l", mktime(0,0,0,27,05,2017)) . "<br><br>";
echo date("M-d-Y",mktime(0,0,0,12,36,2017)) . "<br>";
echo date("M-d-Y",mktime(0,0,0,14,1,2017)) . "<br>";
echo date("M-d-Y",mktime(0,0,0,1,1,2017)) . "<br>";
echo date("M-d-Y",mktime(0,0,0,1,1,2017)) . "<br>";
?>

</body>
</html>
