var taxi1 = document.getElementById('car1'),
    moveLeft = document.getElementById('right'),
    moveRight = document.getElementById('right'),
    moveUp = document.getElementById('down'),
    moveDown = document.getElementById('down'),
    moveAgain1 = document.getElementById('up'),
    reqID1,
    direction1;

var taxi2 = document.getElementById('car2'),
    moveLeft = document.getElementById('right'),
    moveRight = document.getElementById('right'),
    moveUp = document.getElementById('down'),
    moveDown = document.getElementById('down'),
    moveAgain2 = document.getElementById('up'),    
    reqID2,
    direction2;

function changeDirection1(arrow) {
    direction1 = arrow;
}

function changeDirection2(arrow) {
    direction2 = arrow;
}

function changeDirection3(arrow) {
    direction3 = arrow;
}

function changeDirection4(arrow) {
    direction4 = arrow;
}

var count = 0;

function startMoving1() {
    if (direction1 === 'right') {
        taxi1.style.left = (taxi1.offsetLeft += 2) + 'px';
    } else if (direction1 === 'left') {
        taxi1.style.left = (taxi1.offsetLeft -= 2) + 'px';
    } else if (direction1 === 'up') {
        taxi1.style.top = (taxi1.offsetTop -= 2) + 'px';
    } else if (direction1 === 'down') {
        taxi1.style.top = (taxi1.offsetTop += 2) + 'px';
    }
    // tells the browser to keep running the car 60 frames per second.
    reqID1 = window.requestAnimationFrame(startMoving1);
    
}
function startMoving2() {
    if (direction2 === 'right') {
        taxi2.style.left = (taxi2.offsetLeft += 2) + 'px';
        
    } else if (direction2 === 'left') {
        taxi2.style.left = (taxi2.offsetLeft -= 2) + 'px';
    } else if (direction2 === 'up') {
        taxi2.style.top = (taxi2.offsetTop -= 2) + 'px';
    } else if (direction2 === 'down') {
        taxi2.style.top = (taxi2.offsetTop += 2) + 'px';
    }
    
    // tells the browser to keep running the car 60 frames per second.
    reqID2 = window.requestAnimationFrame(startMoving2);
}

function startMoving3() {
    if (count == 384) {
        console.log("Collision");

        var x = document.getElementById("car1");
        var v = x.getAttribute("src");
        v = "img/explosion.gif";
        x.setAttribute("src", v);
        document.getElementById("car1").width = 300;
        document.getElementById("car1").height = 300;

        var x = document.getElementById("car2");
        var v = x.getAttribute("src");
        v = "img/explosion.gif";
        x.setAttribute("src", v);
        document.getElementById("car2").width = 300;
        document.getElementById("car2").height = 300;

        // document.getElementById("car1").innerHTML = '<img src="img/explosion.gif" />';
        // document.getElementById("car2").innerHTML = '<img src="img/explosion.gif" />';
        // reset();
        // wait(3000);
        // reset();
    }
    
    count++;
    console.log(count);
    if (direction3 === 'right') {
        taxi1.style.left = (taxi1.offsetLeft += 1) + 'px';
    } else if (direction3 === 'left') {
        taxi1.style.left = (taxi1.offsetLeft -= 1) + 'px';
    } else if (direction3 === 'up') {
        taxi1.style.top = (taxi1.offsetTop -= 1) + 'px';
    } else if (direction3 === 'down') {
        taxi1.style.top = (taxi1.offsetTop += 1) + 'px';
    }

    // tells the browser to keep running the car 60 frames per second.
    reqID1 = window.requestAnimationFrame(startMoving3);
}

function startMoving4() {   
    // console.log("Okay2");    
    if (direction4 === 'right') {
        taxi2.style.left = (taxi2.offsetLeft += 1) + 'px';
    } else if (direction4 === 'left') {
        taxi2.style.left = (taxi2.offsetLeft -= 1) + 'px';
    } else if (direction4 === 'up') {
        taxi2.style.top = (taxi2.offsetTop -= 1) + 'px';
    } else if (direction4 === 'down') {
        taxi2.style.top = (taxi2.offsetTop += 1) + 'px';
    }

    // tells the browser to keep running the car 60 frames per second.
    reqID2 = window.requestAnimationFrame(startMoving4);
}

function stopMoving1() {
    // cancel requestAnimationFrame function to stop moving.
    window.cancelAnimationFrame(reqID1);
}

function stopMoving2() {
    // cancel requestAnimationFrame function to stop moving.
    window.cancelAnimationFrame(reqID2);
}

function reset() {
    location.reload();
}

// EventListener Mousedown
moveRight.addEventListener('mouseover', function () {
    changeDirection1('right');
    startMoving1();

});
moveRight.addEventListener('mouseout', stopMoving1);

moveLeft.addEventListener('mouseover', function () {
    changeDirection2('left');
    startMoving2();
});
moveLeft.addEventListener('mouseout', stopMoving2);

moveUp.addEventListener('mouseover', function () {
    changeDirection3('right');
    startMoving3();
});
moveUp.addEventListener('mouseout', stopMoving1);

moveDown.addEventListener('mouseover', function () {
    changeDirection4('left');
    startMoving4();
});
moveDown.addEventListener('mouseout', stopMoving2);

moveAgain1.addEventListener('mouseover', function () {
    changeDirection3('right');
    startMoving1();
});
moveAgain1.addEventListener('mouseout', stopMoving1);

moveAgain2.addEventListener('mouseover', function () {
    changeDirection4('left');
    startMoving2();
});
moveAgain2.addEventListener('mouseout', stopMoving2);

function wait(ms) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
        end = new Date().getTime();
    }
}