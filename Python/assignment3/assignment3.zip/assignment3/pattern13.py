num = int(input('Enter a num: '))

for i in reversed(range(1, num + 1)):
    print(i * (str(i) + ' '))